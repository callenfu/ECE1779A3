from __future__ import absolute_import

import click
from click import *  # noqa

click.disable_unicode_literals_warning = True
