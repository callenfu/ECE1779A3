# ECE1779A3

pip install flask
pip install boto3