if __name__ == "__main__":
    print(
        "Type annotations for boto3 1.16.11\n"
        "Version:         1.16.11.0\n"
        "Builder version: 3.2.2\n"
        "Docs:            https://pypi.org/project/boto3-stubs/\n"
        "Changelog:       https://github.com/vemel/mypy_boto3_builder/releases"
    )
